import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lenta',
  templateUrl: './lenta.component.html',
  styleUrls: ['./lenta.component.css']
})
export class LentaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
