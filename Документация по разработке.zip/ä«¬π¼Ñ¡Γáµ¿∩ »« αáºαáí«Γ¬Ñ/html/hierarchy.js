var hierarchy =
[
    [ "TDataModule", null, [
      [ "Tdm", "class_tdm.html", null ]
    ] ],
    [ "TForm", null, [
      [ "Tfm", "class_tfm.html", null ]
    ] ]
];