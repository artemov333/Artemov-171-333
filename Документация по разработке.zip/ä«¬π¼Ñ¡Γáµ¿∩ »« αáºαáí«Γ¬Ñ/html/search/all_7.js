var searchData=
[
  ['queryvisits_77',['queryVisits',['../class_tdm.html#a0d3981ab81c74d49f90d283e39504c39',1,'Tdm']]]
];
