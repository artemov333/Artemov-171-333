var _det_sad_8cpp =
[
    [ "FMXmain", "_det_sad_8cpp.html#aa0366a123141685cd806cb00a48f1f8f", null ],
    [ "USEFORM", "_det_sad_8cpp.html#a9adc4d64d77f524135ba5e3830a60795", null ],
    [ "USEFORM", "_det_sad_8cpp.html#ae7f1b32d9fde69acaab8e59aecb3b769", null ]
];