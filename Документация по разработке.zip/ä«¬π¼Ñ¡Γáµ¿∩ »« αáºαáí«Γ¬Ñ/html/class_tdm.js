var class_tdm =
[
    [ "Tdm", "class_tdm.html#abecfb8bae4bf6088aea7e6ce8a7acc09", null ],
    [ "SendMessage", "class_tdm.html#a49c4ed8f0535ea7bfdd061d8df784c71", null ],
    [ "FDConnection1", "class_tdm.html#a73d46417d3f345bebb4e48722fbe9395", null ],
    [ "FDGUIxWaitCursor1", "class_tdm.html#a805e7899ecbeb20853d07232ce0b1c17", null ],
    [ "FDPhysFBDriverLink1", "class_tdm.html#a3da2f90b62f64fc5922ee79261b41ff2", null ],
    [ "FDQuery1", "class_tdm.html#a6f983d45b107dee6b70057d95a3b756b", null ],
    [ "procSendMess", "class_tdm.html#a80d82ca9bfc352337d9b9c2fdc42b3f7", null ],
    [ "queryVisits", "class_tdm.html#a0d3981ab81c74d49f90d283e39504c39", null ]
];