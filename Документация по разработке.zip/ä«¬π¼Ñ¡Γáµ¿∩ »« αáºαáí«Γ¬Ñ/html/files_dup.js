var files_dup =
[
    [ "DetSad.cpp", "_det_sad_8cpp.html", "_det_sad_8cpp" ],
    [ "DetSadPCH1.h", "_det_sad_p_c_h1_8h.html", null ],
    [ "dmu.cpp", "dmu_8cpp.html", "dmu_8cpp" ],
    [ "dmu.h", "dmu_8h.html", "dmu_8h" ],
    [ "fmu.cpp", "fmu_8cpp.html", "fmu_8cpp" ],
    [ "fmu.h", "fmu_8h.html", "fmu_8h" ]
];