var annotated_dup =
[
    [ "Tdm", "class_tdm.html", "class_tdm" ],
    [ "Tfm", "class_tfm.html", "class_tfm" ]
];